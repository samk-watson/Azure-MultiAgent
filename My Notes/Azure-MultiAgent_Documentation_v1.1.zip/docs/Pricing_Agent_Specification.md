# Pricing Agent Specification — Version 1.1

> **Document status:** Detailed design baseline for review, following product-owner approval of consolidated requirements CR-01 on 31 October 2026. The named CR-01 requirements are approved; suggested field schemas, exact algorithms, MCP signatures, and database structure remain proposals requiring component-level approval. No implementation code is authorized by this document.
>
> **Governing files:** `PRD_v1.1.md`, `Approved_Architecture_v1.1.md`. Research evidence came from the *separate* ZavaShop research exercise and is not a runtime dependency. Version 1 is **recommendation-only**; never submit orders, execute stock transfers, book shipments, or update prices.


## 1. Responsibilities and approved requirements

Provide source-backed retail price and cost assessment, policy-constrained recommendation and explainable margin scenarios. **Never modify or publish a price.**

- **PRC-11 (approved):** Use validated and typed demand/stock-risk signals with provenance and explicit unknown states; never fabricate signals.
- **PRC-12 (approved):** Provide a baseline price/margin assessment and, when relevant verified procurement/shipping cost information exists, a clearly qualified later scenario.
- **PRC-13 (approved):** Unknown SKU/location must not trigger a fabricated fallback price.

## 2. Proposed input/output contract

| Direction | Candidate fields (not finalized) | Validation |
|---|---|---|
| Request | `schema_version`, `sku_id`, `location_id`, `mode` (`baseline` / `cost_scenario`), `validated_demand_signal`, `validated_stock_risk`, `candidate_costs`, `correlation_id` | Baseline can run without Inventory only for independent validated inputs; no assumed high/critical. |
| Response | `status`, `current_price`, `base_unit_cost`, `current_unit_margin`, `margin_percent`, `recommended_price`, `scenario_margin`, `cost_basis`, `policy_version`, `rationale`, `warnings[]`, `errors[]`, `provenance[]` | Unknown inputs remain unavailable; separate amounts/percent and estimates/facts. |

Financial amount precision, percentage denominators, allocation of freight per unit and currency policy require separate approval; do not infer accounting landed cost from a simple purchase plus shipping estimate.

## 3. Proposed read-only MCP tools

`get_current_price`, `get_product_cost`, `get_pricing_rules`, `get_price_history` remain proposed. The current workshop has a single `recommend_price` MCP tool; new server functionality is subject to source coverage and approved policy. Business-service layer owns all calculations, policy checks, price-floor/ceiling enforcement and rounding, exposed through approved MCP. LangGraph orchestration assembles verified results without duplicating price arithmetic.

## 4. Research evidence and gaps

The side-project report describes three SKU/store price rows, including `current_price`, `unit_cost`, `floor_price`, `ceiling_price`, `category`. ZavaShop applies caller-provided free-text `demand_signal` and `stock_risk_level`, then adjusts/clamps price; unknown SKU/store gets a synthetic manual-review price row. It reports **no** sourced demand, price history, promotions, competitor data or linked freight and supplier cost model. None of those missing fields is available merely because our proposed schema contains it. Verify source/license and apply distinctive test-fixture provenance before import.

## 5. Baseline/final workflow relationship

Baseline stage: retrieve actual current price, unit cost and policy; evaluate only validated inputs currently available. If demand/Inventory risk is required but missing, return an incomplete baseline component and explain the gap. Inventory and baseline may execute in parallel only without falsely assuming an Inventory result. Final scenario stage: after Supplier/Logistics, assess validated procurement and freight estimates when materially relevant under an approved policy. Present both results with clear price and cost sources. Neither stage alters operational prices.

## 6. Tests / acceptance

Unknown SKU/store yields explicit not-found and **never** the workshop's artificial price row; unknown demand/risk has no automatic adjustment; deterministic rounding and floor/ceiling tests; currency mismatch; missing supplier/shipping estimates; cost provenance; consistent typed A2A contract; MCP failure/timeouts; negative/contradictory monetary inputs; unauthorized price update refusal. Scenario output distinguishes forecast/estimate from realized margin.

## 7. Decisions required before coding

Signal enums and source authority, price-change objective, policy versions, floor/ceiling validation, decimal rounding, tax/freight treatment, cost allocation, material-change threshold, persistence/audit retention, MCP signatures and schema mapping. **Pricing remains advice-only in Version 1.**
