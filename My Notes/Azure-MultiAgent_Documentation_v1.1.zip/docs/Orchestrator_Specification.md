# Orchestrator Specification — Version 1.1

> **Document status:** Detailed design baseline for review, following product-owner approval of consolidated requirements CR-01 on 31 October 2026. The named CR-01 requirements are approved; suggested field schemas, exact algorithms, MCP signatures, and database structure remain proposals requiring component-level approval. No implementation code is authorized by this document.
>
> **Governing files:** `PRD_v1.1.md`, `Approved_Architecture_v1.1.md`. Research evidence came from the *separate* ZavaShop research exercise and is not a runtime dependency. Version 1 is **recommendation-only**; never submit orders, execute stock transfers, book shipments, or update prices.


## 1. Approved responsibilities and CR-01 changes

Own the parent LangGraph workflow, typed request/result validation, specialist delegation via standard A2A, workflow status, recovery, conversation-to-workflow routing, traceable consolidated recommendations and human review signals.

- **ORC-11:** Versioned, validated structured A2A domain artifacts and actual A2A interoperability; never trust free-text specialist response as authority.
- **ORC-12:** Source-backed quantities and risk/demand inputs; no hardcoded workshop values, and no LLM-only policy decisions.
- **ORC-13:** PostgreSQL-backed durable checkpointing, per-step status, partial results, bounded retries and resumable processing in V1.
- **ORC-14:** Auth, trace propagation, audit and V1 read-only boundaries across API/A2A/MCP/services.

## 2. Deterministic stock-out graph — proposed nodes

```text
START -> validate_request -> register_workflow
      -> parallel[ inventory_assessment, baseline_pricing ]
      -> verify_join -> replenishment_needed?
                    no  -> consolidate -> persist -> END
                    yes -> supplier_evaluation -> logistics_evaluation
                        -> conditional_final_pricing -> consolidate -> persist -> END
```

The baseline Pricing branch uses only validated independent price/cost/signal inputs; unknown inventory-dependent risk is not guessed. A branch can yield qualified partial evidence. Supplier is called only when the Inventory result supports replenishment; if quantity policy is missing, supplier quantity-dependent work is unavailable rather than supplied with an arbitrary number. Logistics inputs must be parsed/validated typed Supplier outputs, including quantity, destination and origin where supported.

## 3. Parent shared state proposal (not finalized)

| Key | Ownership/notes |
|---|---|
| `workflow_id`, `correlation_id`, `trace_id`, `request` | API/Orchestrator; stable identifiers and validated request |
| `inventory_result`, `pricing_baseline` | Parallel nodes write separate fields |
| `replenishment_decision`, `supplier_result`, `logistics_result`, `pricing_final` | Dedicated workflow stages with typed optional/partial data |
| `step_statuses`, `workflow_status`, `errors`, `warnings`, `assumptions` | Explicit and append-only or controlled reducers; design concurrency-safe |
| `recommendations`, `provenance`, `approval_review_state` | Advisory results and simulated review state, never transaction execution |
| `checkpoint/thread_id`, `a2a_task_ids` | Durable workflow identity distinct from A2A task IDs |

Specialist LangGraph state remains private. No parallel writes to an unprotected shared state key. Error/status enum must distinguish complete, incomplete/partial, not found, failed and cancelled where needed.

## 4. Protocol and business boundaries

- Standard A2A Agent Cards and protocol task handling. Orchestrator is client, specialists servers; use supported version/SDK and contract compatibility tests.
- Each specialist returns typed domain artifacts with schema versions; reject wrong SKU/location, mismatched correlation, malformed payload or unsupported version. Keep protocol task status separate from business result status.
- Each specialist agent accesses approved MCP tools; handlers delegate to deterministic read-only business services with PostgreSQL data; Orchestrator never performs specialist calculations in its prompt.
- Authenticated A2A/MCP; least-privilege tool exposure; no V1 endpoints for PO submission, transfer execution, carrier booking or price update. Log decisions/tool events with scoped sensitive-data policies.

## 5. Durability and API execution

- FastAPI initiates workflow, returns workflow ID promptly; clients poll/subscribe for progress and results. Choose a durable dispatch mechanism in implementation review (do not assume in-process background tasks are durable).
- Checkpoints in PostgreSQL separate from retail data; resume with stable workflow identity; preserve prior successes, bound retries and distinguish permanent/transient errors. Cancellation and partial completion are explicit.
- Idempotency of task retries is required; V1 remains read-only with advisory artifacts. No pretend completed operational actions.
- Conversational entry is developed after deterministic workflow; it can route to specialists and invoke the approved deterministic path but cannot weaken policy, data provenance, schemas or authorization.

## 6. Acceptance / tests

- Valid request uses Inventory + baseline Pricing concurrently without hardcoded inventory risk; no shortage bypasses Supplier/Logistics; shortage uses service-calculated replenishment quantity.
- Incorrect A2A agent-card/structured artifact/schema version or SKU rejected; independently test standard A2A client/server interoperability.
- Supplier and Logistics downstream typed values preserve the same quantity, SKU and destination; missing carrier coverage or costs cannot become guaranteed delivery/margin.
- Restart Orchestrator after a successful specialist step: checkpointed results preserved, incomplete steps resumed/reported correctly.
- Parallel state conflict, timeout, retry cap, cancellation, partial outputs, permission denial, audit/trace continuity and V1 prohibited transaction request tested.
- Conversational call can invoke deterministic workflow and return supported outputs without invented data.

## 7. Decisions required before coding

A2A/MCP SDK versions and auth, shared state schema/error taxonomy, checkpoint implementation, durable execution/queue choice, timeout/retry policy, partial-result semantics, cancellation, endpoint shape, alerting/audit retention and model/provider selection. **No implementation authorized by this document alone.**
