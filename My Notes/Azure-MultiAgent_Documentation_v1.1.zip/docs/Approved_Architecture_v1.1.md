Approved End-to-End Integration Architecture \| Architecture Design 4 \| 30 October 2026

Status: Approved by product owner. This document records the agreed logical architecture and distinguishes implementation details that remain to be finalized.

# 1. Executive Summary

Version 1 is an independent, ZavaShop-aligned retail supply-chain decision-support application. A LangGraph Orchestrator coordinates four independently deployable specialist agents (Inventory, Supplier, Logistics, Pricing) using standard Agent-to-Agent (A2A) communication. Each specialist accesses read-only business tools through Model Context Protocol (MCP). Deterministic Python services own business rules and authoritative data. Agents analyze and recommend; they do not execute transactions in Version 1.

# 2. Logical Architecture

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th>PRESENTATION<br />
Retail dashboard | Stock-out planning | AI chat | Recommendation review</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

↓

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th>APPLICATION<br />
FastAPI application API | Request validation | Workflow status</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

↓

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th>ORCHESTRATION<br />
LangGraph Orchestrator | Deterministic planning | Conversational mode</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

↓

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th>A2A SPECIALISTS<br />
Inventory Agent | Supplier Agent | Logistics Agent | Pricing Agent</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

↓

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th>MCP TOOL LAYER<br />
Inventory MCP | Supplier MCP | Shipping MCP | Pricing MCP</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

↓

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th>BUSINESS &amp; DATA<br />
Deterministic business services | PostgreSQL | ZavaShop sample fixtures</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Protocol boundaries: UI ↔ API over HTTPS; Orchestrator ↔ specialist agents over standard A2A; specialist agents ↔ tools over MCP; MCP servers ↔ conventional business services via validated internal interfaces.

# 3. Agent Responsibilities

| Component    | Primary responsibility                                                                           | Version 1 boundary                                           |
|--------------|--------------------------------------------------------------------------------------------------|--------------------------------------------------------------|
| Orchestrator | Validate requests; coordinate LangGraph; delegate through A2A; consolidate and validate results. | Recommendations only; no direct business mutations.          |
| Inventory    | Assess stock, shortages, replenishment quantities, alternative locations.                        | May recommend transfers; cannot create or execute transfers. |
| Supplier     | Evaluate availability, prices, lead times, and proposed purchase-order details.                  | No purchase-order submission.                                |
| Logistics    | Evaluate shipment options, cost, transit time, feasibility.                                      | No booking or label creation.                                |
| Pricing      | Evaluate price, costs, margins, and price/no-change recommendation.                              | No price updates.                                            |

# 4. Deterministic Stock-Out Workflow

- 1\. Validate and register the stock-out request; assign workflow and trace identifiers.

- 2\. Run Inventory assessment and baseline Pricing assessment in parallel, writing to separate state fields.

- 3\. If replenishment is unnecessary, return findings without invoking Supplier or Logistics.

- 4\. If needed, invoke Supplier to identify feasible replenishment candidates.

- 5\. Invoke Logistics only for candidates with valid shipping origins and quantities.

- 6\. Optionally reassess Pricing if new procurement and freight costs materially affect margins.

- 7\. Validate structured results, consolidate recommendations, report assumptions and warnings, and present for review.

A failed or unavailable downstream agent must not cause fabricated recommendations. Partially completed plans are explicitly marked incomplete.

# 5. Shared State and Ownership

| State group               | Fields / examples                                   | Owner                                   |
|---------------------------|-----------------------------------------------------|-----------------------------------------|
| Request and identity      | workflow_id, request, trace_id                      | Orchestrator                            |
| Specialist results        | inventory_result, supplier_result, logistics_result | Orchestrator stores validated artifacts |
| Pricing                   | pricing_baseline, pricing_final (optional)          | Orchestrator                            |
| Execution                 | workflow_status, step_statuses, errors, warnings    | Orchestrator                            |
| Decision support          | recommendations, assumptions, provenance            | Orchestrator                            |
| Specialist internal state | Local node progress, tool results, checkpoints      | Each specialist service                 |

Agents do not share a mutable LangGraph state object. A2A carries validated business contracts; the Orchestrator stores the resulting artifacts. Parallel nodes update distinct fields to avoid merge conflicts.

# 6. A2A Communication Contract

- Each specialist publishes a standard Agent Card with its capabilities and supported interfaces. Agent Cards support discovery but do not grant authorization.

- The Orchestrator submits a task through a compatible A2A SDK, receives protocol task identifiers/status, and obtains a structured result artifact.

- Business correlation_id and distributed trace context link agent tasks to the parent workflow; they are distinct from A2A task IDs.

- Artifacts are validated against versioned Pydantic contracts before use. Authentication, timeouts, cancellation, and bounded retries are required.

# 7. MCP and Business-Service Boundaries

| Agent     | Illustrative read-only MCP tools                                                               |
|-----------|------------------------------------------------------------------------------------------------|
| Inventory | check_stock; get_inventory_locations; get_replenishment_rules; get_inbound_inventory           |
| Supplier  | list_suppliers; get_supplier_catalog; get_supplier_lead_times; get_supplier_terms              |
| Logistics | get_shipping_options; estimate_shipping_cost; estimate_delivery_time; get_shipping_constraints |
| Pricing   | get_current_price; get_product_cost; get_pricing_rules; get_price_history                      |

MCP servers expose controlled, schema-validated tools. Business services perform authoritative calculations and data access. Tool availability and schema details will be reconciled with actual ZavaShop fixtures before coding.

# 8. Persistence, Audit, and Recovery

| Data                     | Proposed persistence                                        |
|--------------------------|-------------------------------------------------------------|
| Retail data              | PostgreSQL business schema                                  |
| Orchestrator checkpoints | Durable LangGraph checkpoint storage, logically isolated    |
| Specialist checkpoints   | Separate checkpoint namespaces or stores                    |
| Workflow results         | Application schema with workflow and recommendation records |
| Audit and telemetry      | Structured events, correlation IDs, distributed traces      |
| Development fixtures     | Version-controlled sample data files                        |

Recovery: preserve completed assessments; retry only failed operations within limits; resume from durable checkpoints when feasible. Invalid artifacts are rejected, duplicates are deduplicated, and unrecoverable failures produce explicit partial or failed statuses. Since Version 1 is read-only, there are no purchase-order, shipment, transfer, or pricing mutations to replay.

# 9. Conversational Orchestration

After deterministic planning is validated, add a conversational LangGraph entry point. It interprets user intent, delegates focused questions to specialist agents through A2A, and can invoke the deterministic stock-out workflow as a controlled operation. Conversation context links to authenticated users and relevant workflow IDs. Responses must distinguish retrieved facts from inferred recommendations and disclose missing data.

# 10. Integration and Acceptance Testing

| Layer             | Required tests                                                                          |
|-------------------|-----------------------------------------------------------------------------------------|
| Business services | Deterministic stock calculations, supplier comparison, freight estimates, pricing rules |
| MCP               | Tool schemas, read-only enforcement, input validation, failures                         |
| Agents            | Structured output, reasoning boundaries, invalid/missing data                           |
| A2A               | Discovery, task lifecycle, artifact validation, timeouts, cancellation                  |
| LangGraph         | Parallel execution, branching, checkpoints, recovery, deduplication                     |
| End-to-end        | Stock-out scenario using verified ZavaShop sample data                                  |
| Conversational    | Intent routing, follow-ups, full-plan invocation                                        |

Prefer deterministic fixtures and mocked LLM/tool responses for repeatable tests, supplemented by targeted real-model integration tests.

# 11. Deployment Strategy

| Stage       | Environment                                            | Approach                                                                                              |
|-------------|--------------------------------------------------------|-------------------------------------------------------------------------------------------------------|
| Local       | Windows/VS Code and containers                         | Run services and dependencies locally; validate complete workflow before cloud deployment.            |
| Azure first | AKS, ACR, Key Vault, managed PostgreSQL, Azure Monitor | Deploy independently scalable services with secure identities, secrets, telemetry, and CI/CD.         |
| AWS second  | EKS, ECR, Secrets Manager, RDS PostgreSQL, CloudWatch  | Reuse application containers and standards-based interfaces; adapt cloud infrastructure and identity. |

OCI images, Kubernetes, standard protocols, environment-based configuration, and OpenTelemetry support portability. Cloud identity, secrets, networking, and model access still require provider-specific integration.

# 12. Approved Architecture Decisions

- One LangGraph Orchestrator with deterministic and conversational modes.

- Four independent LangGraph specialist services with standard A2A interfaces.

- Separate read-only MCP servers backed by conventional business services.

- Versioned structured business contracts and isolated agent state.

- Durable PostgreSQL-backed business/workflow persistence with logical separation.

- Checkpointing, bounded retries, partial-result reporting, and traceability.

- Version 1 delivers analysis and recommendations only; transactional features belong to the commercial release.

- Local development first, Azure AKS deployment second, AWS EKS deployment third.

# 13. Items Deferred to Detailed Implementation Design

- Audit the exact ZavaShop fixtures, licensing, data coverage, and asset reuse rights.

- Select A2A and MCP SDK versions and test interoperability.

- Choose production LLM provider and model configuration.

- Define authentication/authorization, API error taxonomy, and security controls.

- Finalize deployment topology, CI/CD, infrastructure as code, and performance targets.

# 14. Reference Documentation

https://github.com/microsoft/AKS-Lab-GitHubCopilot

https://docs.langchain.com/oss/python/langgraph/overview

https://docs.langchain.com/oss/python/langgraph/persistence

https://a2a-protocol.org/latest/

https://modelcontextprotocol.io/docs/getting-started/intro

---

# 15. CR-01 Integration Architecture Clarifications

**Approval and scope:** All 14 CR-01 requirements were approved on 31 October 2026. This addendum **clarifies** the existing approved logical architecture; it does not replace LangGraph, standard A2A, MCP, PostgreSQL, specialist service boundaries, local-first deployment, or the V1 recommendation-only restriction. For normative business requirements see `PRD_v1.1.md` §12.

## A. Contract ownership and boundaries (ORC-11, ORC-14)

- Shared versioned request/result/error types are owned by the application's `packages/` shared contracts area (ownership convention, exact names subject to design review); each A2A specialist returns a validated structured **domain artifact**, with A2A protocol task metadata kept separate from business correlation/workflow IDs.
- The Orchestrator is the **standard A2A client**; each specialist exposes a standard A2A server and discoverable Agent Card. Agent Card discovery is not authorization. Protocol/SDK compatibility and authenticated invocation require testing, not assumptions.
- Specialist LangGraph nodes access approved MCP tools through an MCP client; MCP handlers validate and delegate to deterministic business services; services own policy, calculations, provenance and PostgreSQL access. Agent nodes do not reimplement business formulas or directly bypass MCP.
- API, A2A, MCP and service calls have explicit trust boundaries, least-privilege authorization, trace/correlation propagation, and structured audit records. Reject malformed or stale untrusted outputs; mask sensitive inputs and do not log credentials.
- V1 domain interfaces expose **no business-mutation/transaction endpoints**. Suggested inventory transfers, procurement drafts, carrier choices and price changes are advisory artifacts, not persisted operational actions.

## B. Deterministic workflow refinements (INV-12, ORC-12, PRC-11/12)

```text
validated request + workflow ID
          |
     +----+------------------+
     |                       |
Inventory assessment      Baseline pricing (validated existing inputs only)
     |                       |
     +-----------+-----------+
                 |
       decide replenishment need
         /                    \
       no                      yes
       |                        |
consolidate findings       Supplier eligible offers
                                |
                       Logistics feasibility/quotes
                                |
                      Final pricing when warranted
                                |
                       consolidate typed findings
```

- Parallel branches write disjoint LangGraph state keys; a join validates both statuses. A failed baseline price lookup must not change inventory evidence.
- No hardcoded order size, demand state, stock risk, supplier or carrier commitment; decisions use validated and source-backed inputs and policy versions.
- Missing or contradictory data yields explicit partial/not-available results, not invented values. The workflow may still produce a *qualified* plan with unavailable dependent recommendations clearly labeled.
- If supplier or shipping data cannot support a complete date/cost, do not claim delivery feasibility or landed margin. No shipment is booked and no PO is submitted.
- Conversational entry is implemented after the deterministic path and may invoke it; it may not bypass the approved read-only business boundaries.

## C. Reliability and execution (ORC-13)

- API returns a workflow identifier promptly and provides status/result lookup rather than holding the browser request open throughout the workflow.
- Orchestrator owns parent state and durable checkpointing in PostgreSQL; specialist runs own their private state. Define checkpoint/thread identity, status enum, retry classification, maximum retries, cancellation and safe resume before code is written.
- Persist the last successful completed steps and explicit errors/warnings; recovery must not synthesize missing specialist results or duplicate business actions. V1 has no operational business transactions.
- Test individual failure, partial completion, resume after process restart, concurrency under parallel branches, idempotent request handling, and trace continuity.

## D. Data architecture (INV-11/13, SUP-11/12, LOG-11/12, PRC-13)

- PostgreSQL hosts a **shared logical business model** so SKU/location IDs align across Inventory, Supplier, Logistics and Pricing; business data, workflow checkpoints, and audit records are logically isolated.
- Research from the separate ZavaShop analysis is not a runtime dependency. Its reports may inform approved source mappings. Import only licensed, reviewed and validated fixtures with provenance; synthetic extension fixtures must be distinctly tagged.
- Missing key means `not_found`/`unavailable`, **not** an invented row. Carrier coverage and transfer eligibility must be source-/policy-backed; the phrase “nearby” cannot mean simply “other location.”
- Numeric, timestamp, currency, lead-time and inventory-demand semantics remain explicit design review gates; no tables or migrations are approved by the architecture addendum.

## E. Verification gates before implementation

| Gate | Evidence |
|---|---|
| Contracts | Approved schema/version/error matrix and standard A2A SDK interoperability test plan |
| Inventory | Business-service policy with no agent-side calculations; unknown record and donor-eligibility examples |
| Supplier and Logistics | Eligible offer/route semantics and time/cost consistency, including absent-data cases |
| Pricing | Baseline vs final cost scenarios, validated signals and unavailable-price behavior |
| Recovery & security | PostgreSQL checkpointer design, authorization matrix, trace and audit plan |
| Data foundation | Approved source-to-target map, license review, fixture manifest, import/seed test plan |

No cloud provisioning, application code generation, or database migrations are authorized by this update alone.
