# Azure-MultiAgent — Approved CR-01 documentation package

**Version:** 1.1  
**Approval:** All 14 consolidated requirements approved by product owner, 31 October 2026.  
**Scope:** Version 1 retail supply-chain analysis and recommendation only; independently built LangGraph + standard A2A + MCP architecture.  
**Implementation status:** Documentation only; no code, schema/migrations, data import or cloud deployment is authorized here.

## Repository placement

Copy the seven `.md` files from this package's `docs/` directory to your main repository's `docs/` directory. Existing v1 originals should remain in place; v1.1 files are versioned additions.

| Document | Nature |
|---|---|
| `PRD_v1.1.md` | Exact original PRD v1 text plus approved CR-01 requirement register and acceptance criteria |
| `Approved_Architecture_v1.1.md` | Exact original architecture text plus compatibility-preserving CR-01 addendum |
| `Inventory_Agent_Specification_v1.1.md` | Original Inventory specification plus approved INV-11/12/13 amendment and ID-collision note |
| `Supplier_Agent_Specification.md` | New proposed component-level specification aligned to SUP-11/12 |
| `Logistics_Agent_Specification.md` | New proposed component-level specification aligned to LOG-11/12 |
| `Pricing_Agent_Specification.md` | New proposed component-level specification aligned to PRC-11/12/13 |
| `Orchestrator_Specification.md` | New proposed component-level specification aligned to ORC-11/12/13/14 |

## Traceability and implementation gates

- **Approved:** The 14 CR-01 requirement statements, the original Version 1 architecture, read-only scope and prior Inventory deterministic-first design decisions.
- **Still proposed:** Component schemas/field names, ranking weights, business formulas, MCP tool signatures, A2A SDK version, database DDL, fixture import and migration plan, latency/retry thresholds.
- **Data evidence:** Findings are from the separately conducted Copilot read-only research reports; not independently executed/tested and not automatically imported into the product.
- **Data foundation:** Before app code, approve PostgreSQL shared schema and source-to-target mapping, license/fixture review, manifest, repeatable seeding and data consistency checks. Original workshop data does not contain all operational data required for end-to-end feasibility; unavailable inputs must stay unavailable.
- **Inventory IDs:** Earlier Inventory document used `INV-11` and `INV-12` as labels for previously adopted implementation decisions. The new approved CR-01 business requirements use those identifiers. Inventory v1.1 explicitly maps old labels to `ID-INV-01`/`ID-INV-02` without changing their substance.

## How to commit

```powershell
git add docs/PRD_v1.1.md docs/Approved_Architecture_v1.1.md docs/Inventory_Agent_Specification_v1.1.md docs/Supplier_Agent_Specification.md docs/Logistics_Agent_Specification.md docs/Pricing_Agent_Specification.md docs/Orchestrator_Specification.md
git commit -m "Add approved CR-01 requirements and v1.1 design specifications"
git push origin main
```

## Next approval checkpoint

Design and approve the shared PostgreSQL business-data model and a repeatable source-validated fixture import/seed plan. Then finalize Inventory MCP request/response schemas and replenishment policy before code generation.
