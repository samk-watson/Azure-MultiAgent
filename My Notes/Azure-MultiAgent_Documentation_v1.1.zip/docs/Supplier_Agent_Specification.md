# Supplier Agent Specification — Version 1.1

> **Document status:** Detailed design baseline for review, following product-owner approval of consolidated requirements CR-01 on 31 October 2026. The named CR-01 requirements are approved; suggested field schemas, exact algorithms, MCP signatures, and database structure remain proposals requiring component-level approval. No implementation code is authorized by this document.
>
> **Governing files:** `PRD_v1.1.md`, `Approved_Architecture_v1.1.md`. Research evidence came from the *separate* ZavaShop research exercise and is not a runtime dependency. Version 1 is **recommendation-only**; never submit orders, execute stock transfers, book shipments, or update prices.


## 1. Responsibilities and approved requirements

- Source and compare **source-backed** SKU-specific supplier offers; evaluate ability to cover the requested replenishment need; prepare a **non-operational purchase-order proposal**, never issue or persist an operational purchase order.
- **SUP-11 (approved):** Exclude ineligible offers based on verified requested quantity and applicable constraints before ranking. Where rules or data are absent, label eligibility **unknown**, not confirmed.
- **SUP-12 (approved):** Compare qualified offers using cost, reliability, lead time, and delivery objective with transparent ranking rationale. No undocumented weighting.

## 2. Proposed request / response contract

| Direction | Candidate fields (not finalized) | Validation / semantics |
|---|---|---|
| Request | `schema_version`, `sku_id`, `destination_location_id`, `required_quantity`, `required_by`, `constraints`, `correlation_id` | Positive quantity; location/SKU validated; deadline optional, timezone explicit if used. |
| Response | `status`, `eligible_offers[]`, `ineligible_offers[]`, `preferred_offer`, `po_proposal`, `warnings[]`, `errors[]`, `provenance[]`, `correlation_id` | No definitive ranking if required policy missing; `po_proposal` is advisory only. |
| Offer | `supplier_id`, `available_qty`, `unit_cost`, `currency`, `lead_time_days`, `reliability`, `policy_version`, `observed_at` | Source currency/date/validity absent in workshop; model optional/unavailable until supported. |
| PO proposal | `sku_id`, `supplier_id`, `destination_id`, `quantity`, `estimated_purchase_cost`, `estimated_ready_date` | Not an operational PO, does not submit or reserve supply; no fabricated `po_id`. |

Do not invent price, stock availability, supplier commitment, tax, MOQ or confirmed calendar ETA.

## 3. Proposed read-only MCP tools

`list_suppliers`, `get_supplier_catalog`, `get_supplier_lead_times`, `get_supplier_terms` were suggested in the approved high-level design, but their exact schemas/availability are **not yet approved**. An optional `evaluate_supplier_offers` read-only calculation tool may be proposed during contract review. The MCP handler calls a deterministic Supplier Business Service, which applies eligibility, ranking and financial arithmetic; the LangGraph agent does not duplicate them. The A2A result must be versioned, structured and validated.

## 4. Research evidence versus missing data

The side-project audit reports four SKU-specific offers across two SKUs and three suppliers with `supplier_id`, `name`, `available_qty`, `unit_cost`, `lead_time_days`, `reliability_score`. The active workshop ranking is reliability-first; it has an MCP `list_suppliers` tool and a `draft_po` tool. It lacks MOQ, supplier terms, offer timestamps, currency fields, origin/dispatch location, live availability and source-backed calendar commitments. A separate `supplier1` package reportedly behaves differently. **Do not adopt either implementation's inconsistencies or treat workshop `draft_po` as authorization to write an order.** Verify upstream data and license before fixture import.

## 5. Proposed deterministic agent flow

Validate structured A2A request → retrieve supplier offers/policy through MCP → validate source fields → delegate eligibility/ranking to deterministic service through MCP → build structured ranked advisory result → publish A2A artifact. Explicitly distinguish eligible, ineligible and unknown/insufficient-information options. No LLM may invent vendor terms or quantities; any optional LLM explanation must be grounded in typed results.

## 6. Failure handling and acceptance

- Unknown SKU or no offers: explicit empty/unavailable result; no synthetic supplier.
- Requested quantity exceeds available offer: exclude or explain insufficiency; do not quietly clamp requested amount.
- Missing lead-time basis, deadline or source freshness: qualify feasibility; no guaranteed arrival date.
- Verify ranking and numeric purchase-cost arithmetic with deterministic fixture tests; test conflicting supplier IDs, invalid quantity, missing policy, MCP timeout, malformed A2A artifact, auth denial, and attempted PO submission.
- Include source and policy version in every recommendation when available; use bound retries and validated partial status for failures.

## 7. Decisions required before coding

Supplier eligibility constraints, ranking objective/weights, split-sourcing, MOQ and partial allocation policy, quantity unit, currency/precision, lead-time start/end semantics, quote freshness and tool schemas; final PostgreSQL source-to-target mapping; contract error enum and SDK compatibility. **No production transaction API in Version 1.**
