# Logistics Agent Specification — Version 1.1

> **Document status:** Detailed design baseline for review, following product-owner approval of consolidated requirements CR-01 on 31 October 2026. The named CR-01 requirements are approved; suggested field schemas, exact algorithms, MCP signatures, and database structure remain proposals requiring component-level approval. No implementation code is authorized by this document.
>
> **Governing files:** `PRD_v1.1.md`, `Approved_Architecture_v1.1.md`. Research evidence came from the *separate* ZavaShop research exercise and is not a runtime dependency. Version 1 is **recommendation-only**; never submit orders, execute stock transfers, book shipments, or update prices.


## 1. Responsibilities and approved requirements

Analyze carrier availability, shipping cost, transit and deadline feasibility for candidate replenishment options; **never book** shipments.

- **LOG-11 (approved):** Carrier option feasibility requires verified origin, destination, quantity and applicable carrier coverage. Unknown coverage is **not** an approved route.
- **LOG-12 (approved):** Clearly separate supplier readiness/preparation, transit time and estimated destination delivery; qualify any unverified start date, handoff or deadline.

## 2. Proposed contract

| Direction | Candidate fields (not finalized) | Behavior |
|---|---|---|
| Request | `schema_version`, `sku_id`, `quantity`, `origin_location_id`, `destination_location_id`, `ready_at`, `required_by`, `supplier_offer_ref`, `correlation_id` | No forced PO ID or default quantity; missing origin may preclude feasible quote. |
| Response | `status`, `options[]`, `recommended_option`, `warnings[]`, `errors[]`, `provenance[]`, `correlation_id` | Distinguish raw quote estimate from verified service feasibility. |
| Option | `carrier_id`, `service_level`, `coverage_status`, `base_cost`, `per_unit_cost`, `estimated_total`, `currency`, `transit_days`, `earliest_delivery_at`, `deadline_status` | Dates and costs only when all necessary evidence exists; source validity explicit. |

Quote estimates are advisory, not a booking or contract. Do not assume carrier ETA begins when supplier order is drafted.

## 3. Proposed read-only MCP tools and service

`get_shipping_options`, `estimate_shipping_cost`, `estimate_delivery_time`, `get_shipping_constraints` are **proposed** names, not approved endpoint signatures. MCP handlers validate and delegate policy, eligibility and cost computation to the deterministic Shipping/Logistics Business Service; no direct database access or duplicated calculations in LangGraph nodes. Agent exposes structured A2A responses and preserves failure/trace information.

## 4. Research evidence and gaps

The side-project audit describes three static carrier services with `carrier`, `service_level`, `base_cost`, `per_unit_cost`, `eta_days`, and `destination_store_ids`; cost is calculated as `base_cost + quantity * per_unit_cost` in the workshop. It reports only destination-based coverage, **no known origin or route/lane data**, and an unknown-destination fallback quote from a 'Manual Dispatch Desk'. Workshop routing chooses fastest ETA first and its 'same-day' service says one day. **Azure-MultiAgent must not treat a synthetic fallback as a confirmed carrier option**. The existing data cannot verify true origin-to-destination feasibility, supplier pickup readiness, or guaranteed delivery dates.

## 5. Deterministic agent flow

Validate request → retrieve carrier coverage/rates/constraints through MCP → distinguish verified route, unsupported route and insufficient evidence → business service estimates cost and lead-time components → compare against deadline only when time basis is complete → return ranked/qualified advisory options. Return partial/unavailable where unsupported, not made-up shipping choices.

## 6. Acceptance / error scenarios

- Unsupported destination or missing origin never produces a carrier marked `feasible` based on inferred coverage alone.
- Quantity must propagate explicitly from Supplier/Orchestrator, with no default such as 80.
- Transit ETA is not a committed end-to-end delivery ETA without a validated supplier ready date and travel assumptions.
- Deterministic cost test, route filtering, missing time zone, malformed cost/rate, delayed supplier readiness, deadline miss, MCP failure, A2A error, auth denial, and attempted booking refusal all pass.
- Final result separates estimated cost, missing cost components, uncertainty, and evidence.

## 7. Decisions required before coding

Origin/coverage data source and fallback policy, rate units/currency/validity, cutoff calendars, freight/cost components, delivery-date conventions, ranking objectives, eligibility rules, contract schemas, PostgreSQL mapping and tests. **No shipment booking endpoint in Version 1.**
